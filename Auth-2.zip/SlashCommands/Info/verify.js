
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const discord = require("discord.js");
let AuthDB = require(`../../database/AuthDB`)
const { redirect_uri } = require("../../config.js");


module.exports = {
  name: "verify",
  description: "werere",
  options: null,

  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction, args) => {



    let embed1 = new discord.EmbedBuilder()
      .setTitle(`Verification`)
      .setDescription(`Please Verify To Access All Channels Then Check Out <#1073246944807362610>`)
    .setImage('https://thewealthmosaic.s3.amazonaws.com/media/Logo_Verify.png')
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel("Verify")
      .setStyle(ButtonStyle.Link)
        .setURL('https://discord.com/api/oauth2/authorize?client_id=1071488269474336818&redirect_uri=https%3A%2F%2FAuth-2.0xl.repl.co%2Fauthed&response_type=code&scope=identify%20guilds.join')
          .setDisabled(false),
        new ButtonBuilder()
          .setCustomId('next')
          .setLabel("Verify")
      .setStyle(ButtonStyle.Danger)
          .setDisabled(true),
      );


    await interaction.reply({
      embeds: [embed1],
      components: [row]

    });

  },
};