  module.exports = {
  Prefix: "$",
  Owners: ["1029847000977506345",], 
  Token: process.env.token,
  mongoPass: process.env.mongoPass,
  Error_log_channel: "1073247019012984933",
  Auth_log_channel: "1073247019012984933", 
  oauth_link: "https://discord.com/api/oauth2/authorize?client_id=1071488269474336818&redirect_uri=https%3A%2F%2FAuth-2.0xl.repl.co%2Fauthed&response_type=code&scope=identify%20guilds.join",
  client_id: "1071488269474336818",
  logchannel: "1073247019012984933",  
  autoroleserver: "1066310897913565234",
  autoroleid: "1073246905154424915", // do it work? Auto role. 
  client_secret: process.env.client,
  redirect_uri: "https://Auth-2.0xl.repl.co/authed",
}//what